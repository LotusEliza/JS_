A Pen created at CodePen.io. You can find this one at https://codepen.io/clownay/pen/QdBPJX.

 Vue.js Modal - Simple is an example of how to make a simple modal using Vue.js 2