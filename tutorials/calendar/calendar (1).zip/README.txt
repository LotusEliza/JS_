A Pen created at CodePen.io. You can find this one at https://codepen.io/sdbrannum/pen/QYqKzw.

 Generate calendar/datepicker with DateFNS and Vue.js.