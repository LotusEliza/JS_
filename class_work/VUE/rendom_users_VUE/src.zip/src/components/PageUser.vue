<template>
    <h1>{{ $route.params }}</h1>
</template>
<script>
export default {
    created() {

    }
}
</script>
<style lang="">
    
</style>
