var counter = 0;

module.exports = function() {
    console.log(counter++);
}